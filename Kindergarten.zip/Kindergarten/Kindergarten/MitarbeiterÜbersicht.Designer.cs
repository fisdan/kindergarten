﻿namespace Kindergarten
{
    partial class MitarbeiterÜbersicht
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitarbeiterÜbersicht));
            this.lbl_Betreuer = new System.Windows.Forms.Label();
            this.lbl_zusGruppe = new System.Windows.Forms.Label();
            this.lbl_Betreuername = new System.Windows.Forms.Label();
            this.lbl_zuständigegruppename = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_KinderProtokoll = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_ZurückÜbersicht = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Betreuer
            // 
            this.lbl_Betreuer.AutoSize = true;
            this.lbl_Betreuer.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Betreuer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Betreuer.ForeColor = System.Drawing.Color.White;
            this.lbl_Betreuer.Location = new System.Drawing.Point(42, 46);
            this.lbl_Betreuer.Name = "lbl_Betreuer";
            this.lbl_Betreuer.Size = new System.Drawing.Size(135, 31);
            this.lbl_Betreuer.TabIndex = 0;
            this.lbl_Betreuer.Text = "Betreuer:";
            // 
            // lbl_zusGruppe
            // 
            this.lbl_zusGruppe.AutoSize = true;
            this.lbl_zusGruppe.BackColor = System.Drawing.Color.Transparent;
            this.lbl_zusGruppe.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_zusGruppe.ForeColor = System.Drawing.Color.White;
            this.lbl_zusGruppe.Location = new System.Drawing.Point(42, 188);
            this.lbl_zusGruppe.Name = "lbl_zusGruppe";
            this.lbl_zusGruppe.Size = new System.Drawing.Size(272, 31);
            this.lbl_zusGruppe.TabIndex = 1;
            this.lbl_zusGruppe.Text = "Zuständige Gruppe:";
            // 
            // lbl_Betreuername
            // 
            this.lbl_Betreuername.AutoSize = true;
            this.lbl_Betreuername.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Betreuername.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Betreuername.ForeColor = System.Drawing.Color.White;
            this.lbl_Betreuername.Location = new System.Drawing.Point(44, 89);
            this.lbl_Betreuername.Name = "lbl_Betreuername";
            this.lbl_Betreuername.Size = new System.Drawing.Size(95, 24);
            this.lbl_Betreuername.TabIndex = 2;
            this.lbl_Betreuername.Text = "Platzhalter";
            this.lbl_Betreuername.Click += new System.EventHandler(this.lbl_Betreuername_Click);
            // 
            // lbl_zuständigegruppename
            // 
            this.lbl_zuständigegruppename.AutoSize = true;
            this.lbl_zuständigegruppename.BackColor = System.Drawing.Color.Transparent;
            this.lbl_zuständigegruppename.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_zuständigegruppename.ForeColor = System.Drawing.Color.White;
            this.lbl_zuständigegruppename.Location = new System.Drawing.Point(44, 236);
            this.lbl_zuständigegruppename.Name = "lbl_zuständigegruppename";
            this.lbl_zuständigegruppename.Size = new System.Drawing.Size(95, 24);
            this.lbl_zuständigegruppename.TabIndex = 3;
            this.lbl_zuständigegruppename.Text = "Platzhalter";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(7, 1040);
            this.label1.TabIndex = 4;
            this.label1.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r" +
    "\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // lbl_KinderProtokoll
            // 
            this.lbl_KinderProtokoll.AutoSize = true;
            this.lbl_KinderProtokoll.BackColor = System.Drawing.Color.Transparent;
            this.lbl_KinderProtokoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_KinderProtokoll.ForeColor = System.Drawing.Color.White;
            this.lbl_KinderProtokoll.Location = new System.Drawing.Point(357, 46);
            this.lbl_KinderProtokoll.Name = "lbl_KinderProtokoll";
            this.lbl_KinderProtokoll.Size = new System.Drawing.Size(250, 31);
            this.lbl_KinderProtokoll.TabIndex = 5;
            this.lbl_KinderProtokoll.Text = "Kinder (Protokoll):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(632, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(7, 1040);
            this.label2.TabIndex = 6;
            this.label2.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r" +
    "\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(955, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(7, 1040);
            this.label3.TabIndex = 7;
            this.label3.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r" +
    "\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // btn_ZurückÜbersicht
            // 
            this.btn_ZurückÜbersicht.BackColor = System.Drawing.Color.White;
            this.btn_ZurückÜbersicht.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ZurückÜbersicht.Location = new System.Drawing.Point(1688, 960);
            this.btn_ZurückÜbersicht.Name = "btn_ZurückÜbersicht";
            this.btn_ZurückÜbersicht.Size = new System.Drawing.Size(214, 64);
            this.btn_ZurückÜbersicht.TabIndex = 26;
            this.btn_ZurückÜbersicht.Text = "Zurück";
            this.btn_ZurückÜbersicht.UseVisualStyleBackColor = false;
            // 
            // MitarbeiterÜbersicht
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Kindergarten.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(1914, 1036);
            this.Controls.Add(this.btn_ZurückÜbersicht);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_KinderProtokoll);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_zuständigegruppename);
            this.Controls.Add(this.lbl_Betreuername);
            this.Controls.Add(this.lbl_zusGruppe);
            this.Controls.Add(this.lbl_Betreuer);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MitarbeiterÜbersicht";
            this.Text = "Übersicht";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Betreuer;
        private System.Windows.Forms.Label lbl_zusGruppe;
        private System.Windows.Forms.Label lbl_Betreuername;
        private System.Windows.Forms.Label lbl_zuständigegruppename;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_KinderProtokoll;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_ZurückÜbersicht;
    }
}