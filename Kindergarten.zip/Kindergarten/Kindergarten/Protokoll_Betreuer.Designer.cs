﻿namespace Kindergarten
{
    partial class Protokoll_Betreuer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Protokoll_Betreuer));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_Kinderalter = new System.Windows.Forms.Label();
            this.lbl_Alter = new System.Windows.Forms.Label();
            this.lbl_NameKind = new System.Windows.Forms.Label();
            this.lbl_Kindername = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_ZurückBetreuer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1036, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(270, 31);
            this.label4.TabIndex = 23;
            this.label4.Text = "Abwesenheitsgrund";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(647, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(276, 31);
            this.label3.TabIndex = 22;
            this.label3.Text = "Abwesenheitsdatum";
            // 
            // lbl_Kinderalter
            // 
            this.lbl_Kinderalter.AutoSize = true;
            this.lbl_Kinderalter.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Kinderalter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Kinderalter.ForeColor = System.Drawing.Color.White;
            this.lbl_Kinderalter.Location = new System.Drawing.Point(150, 271);
            this.lbl_Kinderalter.Name = "lbl_Kinderalter";
            this.lbl_Kinderalter.Size = new System.Drawing.Size(95, 24);
            this.lbl_Kinderalter.TabIndex = 21;
            this.lbl_Kinderalter.Text = "Platzhalter";
            // 
            // lbl_Alter
            // 
            this.lbl_Alter.AutoSize = true;
            this.lbl_Alter.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Alter.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Alter.ForeColor = System.Drawing.Color.White;
            this.lbl_Alter.Location = new System.Drawing.Point(12, 264);
            this.lbl_Alter.Name = "lbl_Alter";
            this.lbl_Alter.Size = new System.Drawing.Size(84, 31);
            this.lbl_Alter.TabIndex = 20;
            this.lbl_Alter.Text = "Alter:";
            // 
            // lbl_NameKind
            // 
            this.lbl_NameKind.AutoSize = true;
            this.lbl_NameKind.BackColor = System.Drawing.Color.Transparent;
            this.lbl_NameKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NameKind.ForeColor = System.Drawing.Color.White;
            this.lbl_NameKind.Location = new System.Drawing.Point(12, 175);
            this.lbl_NameKind.Name = "lbl_NameKind";
            this.lbl_NameKind.Size = new System.Drawing.Size(99, 31);
            this.lbl_NameKind.TabIndex = 19;
            this.lbl_NameKind.Text = "Name:";
            // 
            // lbl_Kindername
            // 
            this.lbl_Kindername.AutoSize = true;
            this.lbl_Kindername.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Kindername.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Kindername.ForeColor = System.Drawing.Color.White;
            this.lbl_Kindername.Location = new System.Drawing.Point(150, 182);
            this.lbl_Kindername.Name = "lbl_Kindername";
            this.lbl_Kindername.Size = new System.Drawing.Size(95, 24);
            this.lbl_Kindername.TabIndex = 18;
            this.lbl_Kindername.Text = "Platzhalter";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(105, 138);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1000, -2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(7, 1040);
            this.label2.TabIndex = 16;
            this.label2.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r" +
    "\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(616, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(7, 1040);
            this.label1.TabIndex = 15;
            this.label1.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r" +
    "\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // btn_ZurückBetreuer
            // 
            this.btn_ZurückBetreuer.BackColor = System.Drawing.Color.White;
            this.btn_ZurückBetreuer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ZurückBetreuer.Location = new System.Drawing.Point(1682, 906);
            this.btn_ZurückBetreuer.Name = "btn_ZurückBetreuer";
            this.btn_ZurückBetreuer.Size = new System.Drawing.Size(214, 64);
            this.btn_ZurückBetreuer.TabIndex = 24;
            this.btn_ZurückBetreuer.Text = "Zurück";
            this.btn_ZurückBetreuer.UseVisualStyleBackColor = false;
            // 
            // Protokoll_Betreuer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Kindergarten.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(1908, 1036);
            this.Controls.Add(this.btn_ZurückBetreuer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_Kinderalter);
            this.Controls.Add(this.lbl_Alter);
            this.Controls.Add(this.lbl_NameKind);
            this.Controls.Add(this.lbl_Kindername);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Protokoll_Betreuer";
            this.Text = "Protokoll_Betreuer";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_Kinderalter;
        private System.Windows.Forms.Label lbl_Alter;
        private System.Windows.Forms.Label lbl_NameKind;
        private System.Windows.Forms.Label lbl_Kindername;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_ZurückBetreuer;
    }
}